describe("yourFunction()", function() {
  it("your description", function() {
    expect(yourFunction1(whatever)).toEqual(true);
  });

  it("your description", function() {
    expect(yourFunction1(whatever)).toEqual(true);
  });

  it("your description", function() {
    expect(yourFunction1(whatever)).toEqual(true);
  });

});

describe("yourFunction2()", function() {
  it("your description", function() {
    expect(yourFunction2(whatever)).toEqual(true);
  });

  it("your description", function() {
    expect(yourFunction2(whatever)).toEqual(true);
  });

  it("your description", function() {
    expect(yourFunction2(whatever)).toEqual(true);
  });

});
